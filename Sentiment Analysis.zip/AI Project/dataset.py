import pickle
from sklearn.datasets import load_files   # load_files function

# importing dataset
# load_files will get the data from the directories and generate classes of text file as 0 and 1
reviews = load_files('txt_sentoken/')
X, y = reviews.data, reviews.target

# Pickling the imported dataset
with open('X.pickle', 'wb') as f:
    pickle.dump(X, f)
with open('y.pickle', 'wb') as f:
    pickle.dump(y, f)