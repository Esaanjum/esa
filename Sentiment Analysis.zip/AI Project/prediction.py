import pickle

# unpickling the vectorizer
with open('tfidfmodel.pickle', 'rb') as f:
    tfidf = pickle.load(f)

# unpickling the classifier
with open('classifier.pickle', 'rb') as f:
    clf = pickle.load(f)

sample = ["Inception is an intense, complex story, but its always coherent, imaginative, and entertaining."]
sample = tfidf.transform(sample).toarray()
if clf.predict(sample)>0.5:
    print("This is a good movie")
else:
    print("This is a bad movie.")

