import pickle
import re  # Regular Expression package
from nltk.corpus import stopwords
import nltk
nltk.download('stopwords') # stopwords function

with open('X.pickle', 'rb') as f:
    X = pickle.load(f)
with open('y.pickle', 'rb') as f:
    y = pickle.load(f)


# pre-processing data using Regular Expression
corpus = []
# remove all the non-word characters and replace them with space
# run loop of length of X list
for i in range(0, len(X)):
    review = re.sub(r'\W', ' ', str(X[i]))  # match anything other than letter,digit or underscore
    review = review.lower()
    review = re.sub(r'\s+[a-z]\s+', ' ', review)  # remove only single characters (by selecting the letters that have space before and after)
    review = re.sub(r'^[a-z]\s+', ' ', review)  # remove the character if a string starts with a single character
    review = re.sub(r'^[a-z]\s+', ' ', review)  # remove extra spaces that we have generated
    corpus.append(review)


# Transforming data into Vector Form
# max_features=2000 means select 2000 most frequent words as features
# min_df=3 means ignore all those words that appear in <=3 documents
# max_df=0.6 means exclude all different words that appear in >=60% documents
# stopwords is used to exclude stopwords

from sklearn.feature_extraction.text import TfidfVectorizer
vectorizer = TfidfVectorizer(max_features=2000, min_df=3, max_df = 0.6, stop_words=stopwords.words('english'))
X = vectorizer.fit_transform(corpus).toarray()


# Creating training and test set
from sklearn.model_selection import train_test_split
# Any Value assigned to Random_State means data will not shuffle before splitting
# text_train is X or Feature columns of Training Data while sentiment_train is the Y or Label Column of training data
text_train, text_test, sentiment_train, sentiment_test = train_test_split(X, y, test_size=0.2, random_state=0)

# Train Using Logistic Regression
from sklearn.linear_model import LogisticRegression
classifier = LogisticRegression()
classifier.fit(text_train, sentiment_train)

# Testing Accuracy
from sklearn.metrics import confusion_matrix
sentiment_pred = classifier.predict(text_test)
cm = confusion_matrix(sentiment_test, sentiment_pred)
print("Model Accuracy is:",((cm[0][0] + cm[1][1])/400)*100)

# Pickling the classifier
with open('classifier.pickle', 'wb') as f:
    pickle.dump(classifier, f)

# pickling the vectorizer
with open('tfidfmodel.pickle', 'wb') as f:
    pickle.dump(vectorizer, f)