import spacy
from spacy import displacy

simple_nlp = spacy.load('en_core_web_sm')  # NLP for date extraction and getting lemmas/basic info
diseases_nlp = spacy.load('en_ner_bc5cdr_md')  # NLP for getting disease entities
doc = simple_nlp("fever from 26th to 28th JUNE with 98C temperature. coughing,head ache for 6 and a half weeks..")
temp = ""
# convert the text into lemmas
for token in doc:
    temp = temp + " " +token.lemma_
doc_lemmas = diseases_nlp(temp)
for ent in doc_lemmas.ents:
    print(ent)

# for token in doc:
#     print(token.text)
# for token in doc:
#     print(token.text, token.lemma_)
# for token in doc:
#     print(f'{token.text:{15}} {token.lemma_:{15}} {token.pos_:{10}} {token.is_stop}')
# for chunk in doc.noun_chunks:
#     print(f'{chunk.text:{30}} {chunk.root.text:{15}} {chunk.root.dep_}')
# for ent in doc.ents:
#     print(ent.text, ent.label_)
# for sent in doc.sents:
#     print(sent)
displacy.serve(doc, style='dep')
# displacy.serve(doc, style='ent', options={'compact':True, 'distance': 100})

# from allennlp.predictors.predictor import Predictor
# predictor = Predictor.from_path("https://storage.googleapis.com/allennlp-public-models/bidaf-elmo.2021-02-11.tar.gz")
# answer = predictor.predict(
#     passage="I have fever and also some cough for 6 and a half weeks and bloody cough for 2 days",
#     question="What is the duration of fever?"
# )
#
# print(answer['best_span_str'])